//script para fazer o json parse desenvolvido por: Danielia.

/*
♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
PRESENTE PRA MELHOR DESENVOLVEDORA FRONT END DO MUNDO
♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
*/

//definindo a URL
var url = "https://raw.githubusercontent.com/mauriciotoledo10/endpoint/master/endPoint.json";

//função que carrega o json usando jquery
//esta função vai imprimir o json completo, sem fazer o json parsing.
function carregaJson(){
    $.getJSON(url, function( data ) {
    
    console.log(data);
});
}

//função que carrega o json usando jquery e faz o json parsing.
//json parsing -> consiste em separar os dados em variável de acordo com o título
//exemplo: json.storeName = imprime o nome da loja
function fullJsonParsing(selector){
    $(document).ready(function () {
        $.getJSON(url,
        function (json) {
            var tr;
            for (var i = 0; i < json.length; i++) {
                tr = $('<tr/>');
                tr.append("<td>" + json[i].id + "</td>");
                tr.append("<td>" + json[i].storeName + "</td>");
                tr.append("<td>" + json[i].score + "</td>");
                $(selector).append(tr);
            }
        });
    });
}


//chamando a função principal
carregaJson();
//chamando a função de parsing
fullJsonParsing();